package com.meiri.jsp.review.model.dao;

public class ReviewDAO {

}
