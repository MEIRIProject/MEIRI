package com.meiri.jsp.review.model.service;

public class ReviewService {

}
